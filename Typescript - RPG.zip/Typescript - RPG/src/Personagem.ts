import { Arqueiro } from "./Arqueiro"
import { Coisa } from "./Coisas"
import { Guerreiro } from "./Guerreiro"
import { Guilda } from "./Guilda"

export class Personagem extends Coisa {
    level: number
    alcance: number = 0
    grupos: Array<string> = []
    

    constructor(nome: string, level: number) {
       super(nome,1000)
        this.level = level
    }

    getNome() {
        return this.nome
    }

    machucar(dano: number, distancia: number, alvo: Coisa) {
        if(alvo instanceof Personagem)
        if (this.ehAliado(alvo)) {
            console.log("Ataque fracassado, Eles são aliados!!")
        } else {
                if (this.alcance < distancia) {
                    console.log("Ataque fracassado,", this.nome, "não tem alcance o suficiente")
                } else {
                    if (alvo.level >= this.level + 5) {
                        dano = dano * 0.5
                    } else if (alvo.level <= this.level - 5) {
                        dano = dano * 1.5
                    } else {
                        dano = dano
                    }
                    if (alvo.vivo == true) {
                        alvo.vida = alvo.vida - dano
                        if (alvo.vida > 0) {
                            alvo.vivo = true
                        } else {
                            alvo.vivo = false
                            alvo.vida = 0
                        }
                    } else {
                        console.log("\n")
                        console.log("Ataque fracassado,", alvo.nome, "esta morto")
                    }
                }
        }
    }

    private ehAliado(alvo: Personagem) {
        for (let i = 0; i < this.grupos.length; i++) {
            for (let j = 0; j < alvo.grupos.length; j++) {
                if (this.grupos[i] == alvo.grupos[j]) {
                    return true
                }
            }
        }
        return false
    }

    curar(cura: number, alvo: Personagem) {
        if (!this.ehAliado(alvo)) {
            console.log("Cura fracassada, eles não são aliados")
        } else {
            if (alvo.vida == 1000) {
                console.log("Cura fracassada, a vida ja esta full")
            } else {
                if (this.ehAliado(alvo) == false) {
                    
                    if (alvo.vivo == true) {
                        alvo.vida = alvo.vida + cura
                        if (alvo.vida > 1000) {
                            alvo.vida = 1000
                        }
                    } else {
                        console.log("\n")
                        console.log("Cura fracassada,", alvo.nome, "esta morto")
                    }
                }
            }
        }
    }

    status(): string {
        return `{nome: ${this.nome}, alcance: ${this.alcance}, vida: ${this.vida}, level: ${this.level}, Guildas: ${this.grupos}, vivo: ${this.vivo}}`
    }
}