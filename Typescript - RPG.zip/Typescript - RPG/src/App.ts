import { Arqueiro } from "./Arqueiro";
import { Guerreiro } from "./Guerreiro";
import { Guilda } from "./Guilda";
import { Personagem } from "./Personagem";
import { Coisa } from "./Coisas";

let legolas = new Arqueiro ("Legolas", 5)
let passolargo = new Guerreiro ("Passo Largo", 5)
let frodo = new Guerreiro ("Frodo", 1)
let copo = new Coisa ("Copo",1)

let cavaleirosnegros = new Guilda ("Cavaleiros Negros")

cavaleirosnegros.addMembro(legolas)
cavaleirosnegros.addMembro(passolargo)

console.log(passolargo.status())

legolas.machucar(500, 2, passolargo)

console.log(passolargo.status())

console.log(passolargo.status())

frodo.curar(100, passolargo)

console.log(passolargo.status())


