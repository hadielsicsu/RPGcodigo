export class Coisa {
    nome: string
    vida: number
    vivo: boolean = true
    grupos:Array<string> = []
    level:number

    constructor(nome: string, vida: number) {
        this.nome = nome
        this.vida = vida

    }
}